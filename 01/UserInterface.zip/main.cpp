#include <iostream>
#include "UserInterface.h"
#include <iomanip>

using namespace std;

int main() {
    UserInterface ui;
    ui.takeChoice();
    return 0;
}
