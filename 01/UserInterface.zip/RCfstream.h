//
// Created by Mali Abramovitch on 18/04/2023.
//

#ifndef INC_01_RCFSTREAM_H
#define INC_01_RCFSTREAM_H


class RCfstream {

};


#endif //INC_01_RCFSTREAM_H
