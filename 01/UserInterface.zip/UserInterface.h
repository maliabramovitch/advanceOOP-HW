//
// Created by Mali Abramovitch on 20/04/2023.
//

#ifndef INC_01_USERINTERFACE_H
#define INC_01_USERINTERFACE_H


#include <string>
#include <sstream>
#include "VirtualDrive.h"
#include <map>

class UserInterface {
    VirtualDrive vd;
    //std::stringstream ss;
    std::map<std::string, int> commands;

    int checkChoice(std::string& input, int &operation); //Receives input from the user and acts accordingly.
    bool checkNArgs(int argsNum, std::string& args); //Checks the legality of the arguments passed by the user.
    std::string getChoiceFromUser(std::string &) const;
    void fillCommends();


public:
    UserInterface();
    ~UserInterface() = default;
    UserInterface(const UserInterface &) = delete;
    UserInterface(UserInterface &&) = delete;
    UserInterface &operator=(const UserInterface &) = delete;
    UserInterface &operator=(UserInterface &&) = delete;

    void printMenu() const;
    void takeChoice(); //Receives input from the user and acts accordingly.

};


#endif //INC_01_USERINTERFACE_H
