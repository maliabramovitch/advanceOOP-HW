//
// Created by Mali Abramovitch on 19/04/2023.
//

#ifndef INC_01_VIRTUALDRIVE_H
#define INC_01_VIRTUALDRIVE_H


class VirtualDrive {



};


#endif //INC_01_VIRTUALDRIVE_H
