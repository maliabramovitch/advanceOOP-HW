#include <iostream>
#include <memory>
#include "Vector.h"

using namespace std;

template<class T>
class Comp {
public:
    bool operator()(const T &a, const T &b) const { return a < b; }
};


int main() {
    try {

        shared_ptr<Vector<string>> v(make_shared<Vector<string>>());
        string s = "Mali Abramovitch was here!";
        v->pushBack(s);
        v->pushBack("ABBA");
        v->pushBack("Agneta");
        v->pushBack("Bjorn");
        v->pushBack("Benny");
        v->pushBack("Anni");
        cout << *v << endl;
        v->sort(Comp<string>());
        cout << *v << endl;
        v->resize(v->size() - 1);
        cout << *v << endl;
        cout << (*v)[5];
    }
    catch (exception &e) {
        cout << e.what();
    }
}